<?php

  get_header();
  
?>
<div class="main">
  <!-- iterate through all posts -->
  <?php if(have_posts()) : while(have_posts()) : the_post(); ?>
  <div class="post">
    
    <!-- only show title and comments if it's a blog post -->
    <?php if (!is_page()) { ?>
    <h3 class="title">
      <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a> 
    </h3>
    
    <div class="post_meta">
      <a href="<?php comments_link() ?>" class="count" title="click to add a new comment">
        <?php comments_number('leave a comment', '1 response', '% responses' ); ?>
      </a>
    </div>
    <?php } ?>
    
    <!-- only show date if it's a blog post -->
    <?php if (!is_page()) { ?>
    <div class="post_date" title="<?php the_time('M d, Y'); ?>">
      <div class="month"><?php the_time('M'); ?></div>
      <div class="day"><?php the_time('d'); ?></div>
      <!-- only display the post year if it's not this year's -->
      <?php if (date('Y') != get_the_time('Y')) { ?>
        <div class="year"><?php the_time('Y'); ?></div>
      <?php } ?>
    </div>
    <?php } ?>
    
    <div class="body">
      <?php the_content('read more...'); ?>
      
      <?php if(is_single()) { 
        the_tags('Tagged with: ');
      } ?>
    </div>
  </div>
  
  
  <?php if(is_single()) { 
    comments_template('', true);
  } ?>
  
  <?php endwhile; ?>
  <?php endif; ?>
  
  <div class="navigation">
    <div class="older">
      <?php next_posts_link('older posts', 0); ?>
    </div>
    <div class="newer">
      <?php previous_posts_link('newer posts', 0); ?>
    </div>
  </div>
</div>

<script>
$(function() {
  var TOPSY = 'http://otter.topsy.com/stats.js?callback=?&url=';
  
  function countTweetbacks() {
    // For each post on the page, get the topsy stats for it
    $('.post').each(function(index, post) {
      var $post = $(post);
      var url = $post.find('h3.title a').attr('href');
      $.getJSON(TOPSY + url, function(data) {
        // If there are tweets, show them beside comment count
        if (data.response.all) {
          $('<div class="tweets" style="display: none">' + 
            '<a href="' + url + '#tweets">' +
              data.response.all + ' tweets' +
            '</a>' +
          '</div>').appendTo($post.find('.post_meta')).fadeIn('slow');
        }
      });
    });
  }
  
  countTweetbacks();
});
</script>

<?php get_footer(); ?>
