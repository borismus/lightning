<!-- Necessary for password-protected posts -->

<?php // Do not delete these lines
if ('comments.php' == basename($_SERVER['SCRIPT_FILENAME'])) die ('Please do not load this page directly. Thanks!');
if (!empty($post->post_password)) { // if there's a password
	if ($_COOKIE['wp-postpass_' . COOKIEHASH] != $post->post_password) {  // and it doesn't match the cookie
?>
<h2><?php _e('Password Protected'); ?></h2>
<p><?php _e('Enter the password to view comments.'); ?></p>
<?php return;
	}
}
?>

<!-- COMMENTS -->
<div class="comments" id="comments">
<?php if ( !empty($comments_by_type['comment']) ) : ?>
  
  <h2 class="comment_number">
    <?php echo count($comments_by_type['comment']); ?> comments
    <span style="float: right">
    <a href="#comment_form">leave comment</a>
    </span>
  </h2>
  
  <?php foreach ($comments_by_type['comment'] as $comment) : ?>
    
  <div class="comment" id="comment-<?php comment_ID() ?>">
    
    <div class="comment_avatar">
      <?php if(function_exists('get_avatar')){
        echo get_avatar($comment, '36');
      } ?>
    </div>
    
    <div class="comment_body">
      <span class="comment_author">
        <?php comment_author_link() ?>
      </span>
      <span class="comment_main">
        <?php comment_text() ?>
      </span>
      <div class="comment_date">
        on <?php comment_time('F jS, Y') ?> at <?php comment_time() ?>
      </div>
    </div>
    
  </div>
  <?php endforeach; // end for each comment ?>
  

<?php endif; // if you delete this the sky will fall on your head ?>
</div>

<form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="comment_form">

  <!-- leave a comment -->
  <h2>leave comment</h2>

  <textarea name="comment" id="comment" cols="80" tabindex="4" placeholder="Your comment please"></textarea>

  <input type="text" name="author" id="author" value="<?php echo $comment_author; ?>" size="40" tabindex="1" placeholder="Name (required)" />

  <input type="text" name="email" id="email" value="<?php echo $comment_author_email; ?>" size="40" tabindex="2" placeholder="Email (required)" />

  <p><input type="text" name="url" id="url" value="<?php echo $comment_author_url; ?>" size="40" tabindex="3" placeholder="Website" /></p>

  <p><input name="submit" type="submit" id="submit" tabindex="5" value="Submit" />
  <input type="hidden" name="comment_post_ID" value="<?php echo $id; ?>" />
  </p>

  <?php do_action('comment_form', $post->ID); ?>

</form>

<!-- TWEETS -->
<div class="comments" id="tweets">
  <h2 class="comment_number">
    <span class="count"></span>
    <span style="float: right">
      <a href="http://twitter.com/?status=<?php the_permalink(); ?> ">post tweet</a>
    </span>
  </h2>
  <!-- Tweets go here -->
</div>

<!-- LINKBACKS -->
<div class="comments" id="pings">
<?php if ( !empty($comments_by_type['pings']) ) : ?>
  
  <h2 class="comment_number">
    <a href="#top">
      <?php echo count($comments_by_type['pings']); ?> pings:
    </a>
  </h2>
  
  <?php foreach ($comments_by_type['pings'] as $comment) : ?>
    
  <div class="comment" id="comment-<?php comment_ID() ?>">
    
    <div class="comment_body">
      <div class="comment_author">
        <?php comment_author_link() ?>
      </div>
      <span class="comment_main">
        <p></p>
      </span>
      <div class="comment_date">
        on <?php comment_time('F jS, Y') ?> at <?php comment_time() ?>
      </div>
    </div>
    
  </div>
  <?php endforeach; // end for each comment ?>
  

<?php endif; // if you delete this the sky will fall on your head ?>
</div>

<script>
/* Copyright (c) 2009 Jon Rohan (http://dinnermint.org)
 * Dual licensed under the MIT (http://www.opensource.org/licenses/mit-license.php) 
 * and GPL (http://www.opensource.org/licenses/gpl-license.php) licenses.
 *
 * Version: 1.0.0
 * Written with jQuery 1.3.2
 */
(function($){$.fn.ghostText = function() {
  return this.each(function(){
    var text = $(this).attr("placeholder");
    if(text!=""&&($(this).val()==""||$(this).val()==text)) {
      $(this).addClass("disabled");
      $(this).val(text);
      $(this).focus(function(){
        $(this).removeClass("disabled");
        if($(this).val()==text) {
          $(this).val("");
        }
      });
      $(this).blur(function(){
        if($(this).val()=="") {
          $(this).val(text);
          $(this).addClass("disabled");
        }
      });
    }
  });
};})(jQuery);

$(function() {
  // enable ghost text on the inputs
  $('input[type="text"], textarea').ghostText();

  // Enable tweetbacks
  var MAX_TWEETS = 10;
  var BASE = 'http://otter.topsy.com/trackbacks.js?callback=?&perpage=' + MAX_TWEETS;
  var ALL = BASE + '&url=';
  var INFL = BASE + '&infonly=1&url=';
  var URL_RE = /(\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/ig;
  var TWEET_RE = /@([A-Za-z0-9_]+)/g;
  
  function urlify(text) {
    return text.replace(URL_RE,"<a href='$1'>$1</a>").
                replace(TWEET_RE, "<a href='http://twitter.com/$1'>@$1</a>");
  }
  
  function processTweetList(list) {
    $.each(list, function(index, tweet) {
      $('<div class="comment">' + 
        '<div class="comment_avatar">' +
          '<img src="' + tweet.author.photo_url + '" class="avatar avatar-36 photo" height="36" width="36"/>' +
        '</div>' +
        '<div class="comment_body">' +
          '<span class="comment_author">' + 
            '<a href="' + tweet.permalink_url + '">' +
            tweet.author.name + '</a></span>' +
          '<span class="comment_main"><p>' + urlify(tweet.content) + '</p></span>' +
          '<div class="comment_date">' + tweet.date_alpha + '</div>'+
        '</div>' +
      '</div>').appendTo('#tweets');
    });
  }
  
  function updateTweetCount(count, total) {
    var str = count + ' tweets';
    if (total) {
      str += ' (total ' + total + ')';
    }
    $('#tweets .comment_number .count').text(str);
    $('#tweets').fadeIn('slow');
  }
  
  function getTweets(url) {
    $.getJSON(ALL + url, function(data) {
      var response = data.response;
      if (response.total > MAX_TWEETS) {
        $.getJSON(INFL + url, function(infl) {
          processTweetList(infl.response.list);
          var count = (infl.response.total > MAX_TWEETS ? MAX_TWEETS : infl.response.total);
          updateTweetCount(count, response.total);
        });        
      } else if (response.total > 0) {
        processTweetList(response.list);
        updateTweetCount(response.total);
      }
    });
  }
  var url = $('h3.title a').attr('href');
  getTweets(url);
});
</script>